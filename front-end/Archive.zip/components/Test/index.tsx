type TestProps = {};

const Test = ({}: TestProps) => <div className=""></div>;

export default Test;
