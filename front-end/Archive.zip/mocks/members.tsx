export const members = [
    {
        id: "0",
        name: "Tyrique",
        login: "username",
        avatar: "/images/avatar-1.jpg",
        admin: true,
    },
    {
        id: "1",
        name: "Josianne",
        login: "username",
        avatar: "/images/avatar-2.jpg",
        admin: false,
    },
    {
        id: "2",
        name: "Ellis",
        login: "username",
        avatar: "/images/avatar-3.jpg",
        admin: false,
    },
    {
        id: "3",
        name: "Alvah",
        login: "username",
        avatar: "/images/avatar-4.jpg",
        admin: false,
    },
    {
        id: "4",
        name: "Chaim",
        login: "username",
        avatar: "/images/avatar-5.jpg",
        admin: false,
    },
    {
        id: "5",
        name: "Kellen",
        login: "username",
        avatar: "/images/avatar-6.jpg",
        admin: false,
    },
];
