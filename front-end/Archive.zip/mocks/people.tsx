export const people = [
    {
        id: "0",
        name: "Anthony",
        email: "anthony@gmail.com",
        avatar: "/images/avatar-1.jpg",
    },
    {
        id: "1",
        name: "Wowa",
        email: "wowa@gmail.com",
        avatar: "/images/avatar-2.jpg",
    },
    {
        id: "2",
        name: "Tom",
        email: "tom@gmail.com",
        avatar: "/images/avatar-4.jpg",
    },
    {
        id: "3",
        name: "Jack",
        email: "jack@gmail.com",
        avatar: "/images/avatar-5.jpg",
    },
    {
        id: "4",
        name: "Antonio",
        email: "antonio@gmail.com",
        avatar: "/images/avatar-6.jpg",
    },
    {
        id: "5",
        name: "Enthony",
        email: "enthony@gmail.com",
        avatar: "/images/avatar-1.jpg",
    },
    {
        id: "6",
        name: "Jony",
        email: "jony@gmail.com",
        avatar: "/images/avatar-2.jpg",
    },
    {
        id: "7",
        name: "Tomy",
        email: "tomy@gmail.com",
        avatar: "/images/avatar-4.jpg",
    },
    {
        id: "8",
        name: "Vlad",
        email: "vlad@gmail.com",
        avatar: "/images/avatar-5.jpg",
    },
    {
        id: "9",
        name: "Kent",
        email: "kent@gmail.com",
        avatar: "/images/avatar-6.jpg",
    },
];
