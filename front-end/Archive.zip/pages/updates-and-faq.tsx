import type { NextPage } from "next";
import UpdatesAndFaqPage from "@/templates/UpdatesAndFaqPage";

const UpdatesAndFaq: NextPage = () => {
    return <UpdatesAndFaqPage />;
};

export default UpdatesAndFaq;
