import type { NextPage } from "next";
import EducationFeedbackPage from "@/templates/EducationFeedbackPage";

const EducationFeedback: NextPage = () => {
    return <EducationFeedbackPage />;
};

export default EducationFeedback;
