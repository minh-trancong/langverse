import type { NextPage } from "next";
import GenerationSocialsPostPage from "@/templates/GenerationSocialsPostPage";

const GenerationSocialsPost: NextPage = () => {
    return <GenerationSocialsPostPage />;
};

export default GenerationSocialsPost;
