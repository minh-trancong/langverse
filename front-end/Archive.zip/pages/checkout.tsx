import type { NextPage } from "next";
import CheckoutPage from "@/templates/CheckoutPage";

const Checkout: NextPage = () => {
    return <CheckoutPage />;
};

export default Checkout;
